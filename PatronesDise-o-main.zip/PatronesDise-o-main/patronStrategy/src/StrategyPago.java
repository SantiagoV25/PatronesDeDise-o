public interface StrategyPago {
    void pagar(int monto);
}
